import java.util.Arrays;
import java.util.Random;
public class Sorting {

  // Do not instantiate.
  private Sorting() {}

  private static Random r = new Random(System.currentTimeMillis());

  // ***************************** Insertion Sorts *****************************

  public static void insertionSort(int[] arr) {
    System.out.println("Insertion Sort:- ");
    for (int i = 1; i < arr.length; i++) {
      int valueToSort = arr[i];
      int j = i;

      while (j > 0 && arr[j - 1] > valueToSort) {
        arr[j] = arr[j -  1];
        j--;
      }
      arr[j] = valueToSort;
    }

    printArray(arr);
  }

  // ***************************** Selection Sort ****************************

  public static void selectionSort(int[] nums) {
	System.out.println("Selection Sort:- ");
    int minindex;
    for (int i = 0; i < nums.length - 1; i++) {
      minindex = i;
      for (int j = i; j < nums.length; j++) {
        if (nums[j] < nums[minindex]) {
          minindex = j;
        }
      }
      if (minindex != i) {
        int tmp = nums[i];
        nums[i] = nums[minindex];
        nums[minindex] = tmp;
      }
    }
    printArray(nums);
  }

  // ***************************** Silly Sorts *****************************
  // *** the silliest sorts of them all
  public static void bogoSort(int[] nums) {
	System.out.println("Bogo Sort:-");
    while (!isSorted(nums)) {
      shuffle(nums);
    }
    printArray(nums);
  }
  
  // Stalin sort eliminates all unsorted numbers in our list and returns a sorted and possibly shorter list
  public static void stalinSort(int[] arr) {
	  System.out.println("Stalin Sort:-");
      int i = 0;
      for (int j = 1; j < arr.length; i++, j++) {
          if (arr[i] > arr[j]) {
              i--;
          } else {
              if (j - i > 1) {
                  arr[i + 1] = arr[j];
              }
          }
      }
      int [] array = Arrays.copyOf(arr, i + 1);
      printArray(array);
  }
  
  // My attempt at a sorting algorithm - Basic Sort
  public static void basicSort(int[] arr) {

	  System.out.println("Basic Sort:-");  
	  int n = arr.length;
	  int temp;
	  int[] array1 = Arrays.copyOf(arr, n);;
	  for(int i = 0; i<n; i++ ){
	         for(int j = i+1; j<n; j++){
	            if(array1[i]>array1[j]){
	               temp = array1[i];
	               array1[i] = array1[j];
	               array1[j] = temp;
	            }
	         }
	      }
	  printArray(array1); 
  }

  // ******shuffle helper for bogoSort
  // Knuth Shuffle
  private static void shuffle(int[] nums) {
    int n, tmp;
    for (int i = nums.length - 1; i > 0; i--) {
      n = r.nextInt(i + 1);
      tmp = nums[i];
      nums[i] = nums[n];
      nums[n] = tmp;
    }
  }

  // **helper function to check if your array is sorted or not
  public static boolean isSorted(int[] nums) {
    for (int i = 0; i < nums.length - 1; i++) {
      if (nums[i] > nums[i + 1]) {
        return false;
      }
    }
    return true;
  }

  // ********print helper class*****
  // Prints the input array
  private static void printArray(int arr[]) {
    int n = arr.length;
    for (int i = 0; i < n; ++i) {
    System.out.print(arr[i] + " ");
    System.out.println();
    }
  }

  /**
   * Reads in a sequence of integers from a file, specified as a command-line argument; counts the
   * number of triples sum to exactly zero; prints out the time to perform the computation.
   *
   * @param args the command-line arguments
   */
  public static void main(String[] args) {
	  
    // use an integer variable to decide which sorting algorithm to use below
    int type = 2;
    //type = 1;
    //type = 2;
    //type = 3;
    //type = 4;

    /// adjust input size to vary size of arrays
    for (int inputSize = 1; inputSize < 101; inputSize++) {
      // vary total Runs to give you many empirical tests
      System.out.print("Input size " + inputSize);

      int totalRuns = 2;
      System.out.println(", Total runs " + totalRuns);
      
      long totalruntime = 0;

      for (int run = 0; run < totalRuns; run++) {

        int[] nums = new int[inputSize];

        for (int i = 0; i < nums.length; i++) {
          nums[i] = r.nextInt(5 * inputSize);
        }

        long time = System.nanoTime();

        switch (type) {
          case 0:
            // selectionsort algorithm
            selectionSort(nums);
            break;

          case 1:
            // insertsort algorithm
            insertionSort(nums);
            break;

          case 2:
            bogoSort(nums);
            break;
            
          case 3:
            stalinSort(nums);
              break;
              
          case 4:
              basicSort(nums);
                break;

          default:
            System.err.printf("\nBad sort ID '%d'", type);
            System.exit(-2);
        }

        totalruntime += System.nanoTime() - time;
      }
      // printout runtime.
      System.out.println("total run time " + totalruntime);
      System.out.println();
    }
  }
}
