// Java program for Naive Pattern Searching 

public class bruteForceSearch {

	    public static void search(String txt, String pat) 
	    { 
	    	int n = txt.length();
	    	int m = pat.length();
	    	int p;
	    	for (int pos = 0; pos <= n-m; pos++ )             
	    	   {
	    		for(p=0; p<m; p++) 
	    	      if (txt.charAt(pos+p) != pat.charAt(p))
	    	    	  break;
	    	      if(p==m) 
	    	    	  System.out.println("We see a pattern at index " + pos);  // Found a match
	    	   }
	        } 

	    public static void main(String[] args) 
	    { 
	        //alter to take text file in..
	        String txt = "ABABDABACDABABCABAB"; 
		    String pat = "ABABCABAB"; 
	        search(txt, pat); 
	    } 
	} 