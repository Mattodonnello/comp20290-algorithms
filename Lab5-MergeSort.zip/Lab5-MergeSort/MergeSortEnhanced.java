import java.util.Arrays;
import java.util.Random;


public class MergeSortEnhanced {
	public static final int CUTOFF = 10;
	
	public static void merge(int[] a, int lo, int mid, int hi){
		if(a[mid] <= a[mid+1]) {
            return;
        }
		
		int l = mid - lo + 1;
        int r = hi - mid;
 
        // Create array to store left side of our array and right side
        int left[] = new int[l];
        int right[] = new int[r];
 
        // Copy left side of array a to left
        for (int x = 0; x < l; x++) {
            left[x] = a[lo + x];
        }
        // COpy right side of array a to right
        for (int y = 0; y < r; y++) {
            right[y] = a[mid + y + 1];
        }
 
        // Initialise variables
        int i = 0; 
        int j = 0;
        int k = lo;
        
        while (i < l && j < r) {
            if (left[i] <= right[j]) {
                a[k] = left[i];
                i++;
            }
            else {
                a[k] = right[j];
                j++;
            }
            k++;
        }

        while (i < l) { // Copy what is left of left array to left
            a[k] = left[i];
            i++;
            k++;
        }

        
        while (j < r) { // Do the same with right
            a[k] = right[j];
            j++;
            k++;
        }
	}
	
	

	
	 private static void sort( int [ ] a,  int l, int r ){
		 if (r <= l + CUTOFF - 1){ 
			 insertionSort(a);
			 return;
			 }	 
		 
      if( l < r ) // If low is less than high
      {
          int center = ( l + r ) / 2; // calculate our middle
          sort( a, l, center ); // recursive calls
          sort( a, center + 1, r );
          merge( a, l, center, r );
      }
  }
	 
	  public static void insertionSort(int[] arr) {
		    for (int i = 1; i < arr.length; i++) {
		      int valueToSort = arr[i];
		      int j = i;

		      while (j > 0 && arr[j - 1] > valueToSort) {
		        arr[j] = arr[j -  1];
		        j--;
		      }
		      arr[j] = valueToSort;
		    }
		  }
	
	 public static void main(String[] args)  { 
		 int[] myArray = { 14, 72, -36, 89, -12, -34, 2, 1, 5, 6, 4, 2, 3, 4, 1, 2 , 3, 4 };
		 int[] myArray2 = { -23 , 2 , -2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15, 24 };
         int n= 10000;
		 
		 int[] list = new int[n];
		 Random random = new Random();
		 for (int i = 0; i < n; i++)
		    {
		        list[i] = random.nextInt(1000);
		    }
		 
		 Stopwatch timer3 = new Stopwatch();
		 sort(list, 0, list.length-1); // call our sort function
	     StdOut.println("Insert Sort elapsed time = " + timer3.elapsedTime());
		 
	       // Print our original array
	        System.out.println("Array before merge sort : " + Arrays.toString(myArray2));
	        Stopwatch timer = new Stopwatch();
	        sort(myArray2, 0, myArray2.length-1); // call our sort function
	        StdOut.println("Merge Sort elapsed time = " + timer.elapsedTime());
	        System.out.println("Our Merge Sorted Array : " + Arrays.toString(myArray2));
	        System.out.println();
	        
	        System.out.println("Array before insert sort : " + Arrays.toString(myArray2));
	        Stopwatch timer2 = new Stopwatch();
	        insertionSort(myArray2); // call our sort function
	        StdOut.println("Insert Sort elapsed time = " + timer2.elapsedTime());
	        System.out.println("Our Insert Sorted Array : " + Arrays.toString(myArray2));
	        
	        
	 }
} 
