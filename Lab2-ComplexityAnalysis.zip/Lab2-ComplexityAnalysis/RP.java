/******************************************************************************
 *  Compilation:  javac ThreeSumA.java
 *  Execution:    java ThreeSum input.txt
 *
 *  @author Robert Sedgewick
 *  @author Kevin Wayne
 ******************************************************************************/

public class RP {

    // Do not instantiate.
    private RP() { }

    /**you should write some comments*/
    public static int multiply(int x, int y){
        int t = 0;
        int z = 1;
        int j = 1;
        
        if(x<0) {
        	x*=-1;
        	z = -1;
        }
        if(y<0) {
        	y*=-1;
        	j= -1;
        }
        
        while (x != 0) {
            if (x % 2 == 1) {
                t += y;
            }

            x /= 2;
            y *= 2;
        }

        return t*z*j; 
    	
    }

    public static int[] multiplyAll(int[] arr, Out monitor) {
        int[] result = new int[arr.length / 2];
        for (int i = 0; i < result.length; i++) {
            int x = arr[2*i];
            int y = arr[2*i + 1];
            result[i] = multiply(x, y);
            monitor.println(result[i]);
        }
        return result;
    }

/**
     * Reads in a sequence of integers from a file, specified as a command-line argument;
     * counts the number of triples sum to exactly zero; prints out the time to perform
     * the computation.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args)  { 
        In in = new In("/Users/matthew/Downloads/practical2-empirical-analysis/data/8Kints.txt");
        int[] a = in.readAllInts();
        Out out = new Out("/Users/matthew/Downloads/practical2-empirical-analysis/data/2ints.txt");

        //Helper file to measure time count function takes to run
        Stopwatch timer = new Stopwatch();

        int[] result = multiplyAll(a, out);
        StdOut.println("elapsed time = " + timer.elapsedTime());
        System.out.println("Number of triples that sum to zero " + result.length);
        for(int i=0; i<result.length; i++) {
        StdOut.println(result[i]);	
        }
        

        
    }
}
