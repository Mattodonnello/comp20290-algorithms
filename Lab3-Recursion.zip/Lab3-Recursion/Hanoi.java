public class Hanoi {

    // Do not instantiate.
    private Hanoi() { }


    public static void powerSet(String str, int index, 
                            String curr)  
    { 

    } 

    /** 
     *  -   0 <- I
     *  __  0 <- J
     *  ___ 0
     * 
        in order to move I, move J first, and make them stable.
     */

    // Recursive function move, which we use to solve our tower of hanoi problem
    public static void move(int n, String src, String dst, String aux, Out out){
    	
    	// Our base case is when we only have one disk (n==1)
        if (n == 1) {
            out.println(String.format("Move disk 1 from %s to %s", src, dst));
            return;
        }
        // We move the top n-1 disks to the aux(auxiliary) tower.
        move(n - 1, src, aux, dst, out);
        
        // We also move one disk from our src(source) rod to our dest(destination) rod
        out.println(String.format("Move disk %d from %s to %s", n, src, dst));
        
     // Then we move the top n-1 disks from our aux to the dest rod
        move(n - 1, aux, dst, src, out); 
    }

    // Recursive Fibonacci function
    public static int fib(int n) {
        if (n == 0 || n == 1) {
            return n;
        }
        return fib(n - 1) + fib(n - 2);
    }

    // Fibonacci function using arrays
    public static int efib(int n) {
        int[] arr = new int[n + 1];
        arr[0] = 0;
        arr[1] = 1;
        for (int i = 2; i <= n; i++) {
            arr[i] = arr[i - 2] + arr[i - 1];
        }
        return arr[n];
    }
/**
     * Reads in a sequence of integers from a file, specified as a command-line argument;
     * counts the number of triples sum to exactly zero; prints out the time to perform
     * the computation.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args)  { 
        
        // We must test our Hanoi with various size disks
        int n = 10;
        int n2 = 4;
        int n3= 1;
        
        // We must create 3 different files to show how our Hanoi function works on different sizes
        Out out = new Out("/Users/matthew/Downloads/practical2-empirical-analysis/data/Hanoi.txt");
        Out out2 = new Out("/Users/matthew/Downloads/practical2-empirical-analysis/data/Hanoi2.txt");
        Out out3 = new Out("/Users/matthew/Downloads/practical2-empirical-analysis/data/Hanoi3.txt");
        String alphabet = "ABCDE";

        //Helper file to measure time count function takes to run
        Stopwatch hanoiTimer = new Stopwatch();
        move(n, "A", "C", "B", out);
        move(n2, "A", "C", "B", out2);
        move(n3, "A", "C", "B", out3);
        StdOut.println(String.format("%s elapsed time = %s","Hanoi", hanoiTimer.elapsedTime()));

        Stopwatch fibTimer = new Stopwatch();
        
     // Make sure both our Fibonacci functions are working accordingly 
        int x = fib(n);
        int y = efib(n);
        StdOut.println(String.format("%s(%d) = %d", "fib", n, x));
        StdOut.println(String.format("%s(%d) = %d", "fib", n, y));
        StdOut.println(String.format("%s elapsed time = %s","Fib", fibTimer.elapsedTime()));

        Stopwatch psetTimer = new Stopwatch();
        for (int i = 0; i < alphabet.length(); i++) powerSet(alphabet, 0, alphabet.substring(i, i + 1));
        StdOut.println(String.format("%s elapsed %s", "Power Set", psetTimer.elapsedTime()));
    }
}
