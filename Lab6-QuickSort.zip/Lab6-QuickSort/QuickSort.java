import java.util.Arrays;

public class QuickSort {
	
	// swap two arr[a] with arr[b]
	public static void swap(int[] arr, int a, int b)
	{
	    int temp = arr[a];
	    arr[a] = arr[b];
	    arr[b] = temp;
	}
	
	public static int partition(int[] array, int start, int end) {

		//pivot - element to be placed in the correct position
		int pivot  = array[end]; 
		int pi = (start-1); 

		for (int j = start; j <= end-1; j++){
		if (array[j] <= pivot){
		pi++;
		swap(array, pi, j);
		}
		}

		int swap = array[pi+1];
	    array[pi+1] = array[end];
	    array[end] = swap;

		return pi+1;
		}
	
	/* array is the input to be sorted, start is the starting index,  end is the end index */
   public static void quickSort(int array[], int start, int end)
	{

	//base case for this recursive function 
	 if(start < end){

	 /* piv is the partitioning index */
	int piv = partition(array, start, end);
	// sort before piv
	quickSort(array, start, piv - 1);  
	// sort after piv
	quickSort(array, piv + 1, end); 
	}
	}
   
   
   public static void main(String[] args)
   {
   int[] array = { 1, 3, -8, 9, 10, 2, -3, 1, 1, -2, 3, 4, 5, 6, 7, 8, 9 };
   int size = array.length;
   Stopwatch timer = new Stopwatch(); 
   quickSort(array, 0, size - 1);
   StdOut.println("Quick Sort elapsed time = " + timer.elapsedTime());
   System.out.println("Sorted array: " + Arrays.toString(array));

}
}
