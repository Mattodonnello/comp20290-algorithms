import java.util.Arrays;

public class enhancedQuickSort {
	public static final int CUTOFF = 10;
	
	// swap two arr[a] with arr[b]
	public static void swap(int[] arr, int a, int b)
	{
	    int temp = arr[a];
	    arr[a] = arr[b];
	    arr[b] = temp;
	}
	
	public static int partition(int[] array, int start, int end, int pivot) {

		//pivot - element to be placed in the correct position
		//int pivot  = array[end]; 
		int pi = (start-1); 

		for (int j = start; j <= end-1; j++){
		if (array[j] <= pivot){
		pi++;
		swap(array, pi, j);
		}
		}

		int swap = array[pi+1];
	    array[pi+1] = array[end];
	    array[end] = swap;

		return pi+1;
		}
	
	
	  public static void insertionSort(int[] arr) {
		    for (int i = 1; i < arr.length; i++) {
		      int valueToSort = arr[i];
		      int j = i;

		      while (j > 0 && arr[j - 1] > valueToSort) {
		        arr[j] = arr[j -  1];
		        j--;
		      }
		      arr[j] = valueToSort;
		    }
		  }
	
	
	  public static void shuffle(int[] array) {
	        int n = array.length;
	        for (int i = 0; i < n; i++) {
	            int rnd = (int) (Math.random() * (i + 1));
	            int swap = array[rnd];
	            array[rnd] = array[i];
	            array[i] = swap;
	        }
	    }  
	  
	  public static int getMedian(int[] array, int start,int end){
	        int mid = (start+end)/2;
	         
	        if(array[start] > array[mid])
	            swap(array, start,mid);
	         
	        if(array[start] > array[end])
	            swap(array, start, end);
	         
	        if(array[mid] > array[end])
	            swap(array, mid, end);
	         
	        swap(array, mid, end);
	        return array[end];
	    }
	  
	
	
	
	/* array is the input to be sorted, start is the starting index,  end is the end index */
   public static void quickSort(int array[], int start, int end)
	{  
	   
	    shuffle(array);
	   
	   if (end <= start + CUTOFF) { 
		      insertionSort(array);
		       return;
		   }


	//base case for this recursive function 
	 if(start < end){

	 /* piv is the partitioning index */
	int piv = getMedian(array, start, end);
	int par = partition(array, start, end, piv);
	
	// sort before piv
	quickSort(array, 0, par - 1);  
	// sort after piv
	quickSort(array, par + 1, end); 
	}
	}
   
   
   public static void main(String[] args)
   {
   int[] array = { 1, 3, -8, 9, 10, 2, -3, 1, 1, -2, 3, 4, 5, 6, 7, 8, 9 };
   int size = array.length;
   Stopwatch timer = new Stopwatch();
   quickSort(array, 0, size - 1);
   StdOut.println("Enhanced Quick Sort elapsed time = " + timer.elapsedTime());
   System.out.println("Sorted array: " + Arrays.toString(array));

}
}
